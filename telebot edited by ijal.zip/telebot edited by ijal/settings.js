const fs = require("fs");
const {
   indonesia
} = require("./language");

// Website Api (jgn di ganti biar gk eror)
global.APIs = {
   alfa: 'https://api.zeeoneofc.my.id', 
}

//buy apikey premium 0887435047326
// Free apikey (silahkan login terus ganti Your Key dgn apikey lu)
global.APIKeys = {
   'https://api.zeeoneofc.my.id': 'KFK4Sdrz9xqLdTF', // 👉 Apikey Telah Disiapkan oleh RexxHayanasi (No Premium)
}

//language 
global.language = indonesia //change indonesia to english if you don't understand the language used by the bot

global.BOT_TOKEN = "6759706104:AAGGHqaQp0GtuPXdIPuvAwGbQK_MHxqlMT0" //create bot here https://t.me/BotFather and get the bot token
global.BOT_NAME = "x " //your bot name
global.OWNER_NAME = " " //your name
global.OWNER_NUMBER = "6285171202705" //your telegram number
global.OWNER = ["https://t.me/Lexzaaaaaa", "https://t.me/Lexzaaaaaa"] // pastikan username sudah sesuai agar fitur khusus owner bisa di pakai
global.THUMBNAIL = "./image/lol.jpg" // ini lol.jpg adalah nama foto di folder image. untuk foto bot
global.DONASI = "./image/donasi.jpg" // foto donasi di folder image
global.lang = language //don't change

//Kalau mau ganti JPG Silakan Cari Folder Image 